class Mother
{
    public void show(){
        System.out.println("Hello World");
    }
}
