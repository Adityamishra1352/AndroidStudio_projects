class duryodhan extends qualities{
    void obey()
    {
        System.out.println("Not obedient");
    }
    
    void kind()
    {
        System.out.println("Not kind");
    }
} 
