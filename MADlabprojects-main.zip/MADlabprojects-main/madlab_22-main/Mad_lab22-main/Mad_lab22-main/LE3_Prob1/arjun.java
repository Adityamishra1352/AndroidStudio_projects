class arjun extends qualities{
    void obey()
    {
        System.out.println("obedient");
    }
    
    void kind()
    {
        System.out.println("kind");
    }
} 
