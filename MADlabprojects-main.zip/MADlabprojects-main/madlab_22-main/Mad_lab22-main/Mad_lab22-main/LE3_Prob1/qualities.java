abstract class qualities{
    void fight()
    {
        System.out.println("All bharatvanshis are fighters");
    }
    
    abstract void obey();
    abstract void kind();
}
