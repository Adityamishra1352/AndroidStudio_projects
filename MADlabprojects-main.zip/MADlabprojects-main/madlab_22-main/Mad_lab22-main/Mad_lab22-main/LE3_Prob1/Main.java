public class Main
{
	public static void main(String[] args) {
		arjun a = new arjun();
	    duryodhan d = new duryodhan();
		
		a.fight();
		a.obey();
		a.kind();
		d.fight();
		d.obey();
		d.kind();
	}
}
