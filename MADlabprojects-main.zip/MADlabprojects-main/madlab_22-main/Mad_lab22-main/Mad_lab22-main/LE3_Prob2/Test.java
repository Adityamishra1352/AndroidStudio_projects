
class Test implements TestTable{
    public void display(){
        System.out.println("In class Test");
    }
}
