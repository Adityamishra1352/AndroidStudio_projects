abstract class AbsTest implements TestTable{

}
