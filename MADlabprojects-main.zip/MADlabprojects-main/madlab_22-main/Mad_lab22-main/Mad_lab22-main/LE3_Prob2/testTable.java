interface TestTable{
    void display();
}
