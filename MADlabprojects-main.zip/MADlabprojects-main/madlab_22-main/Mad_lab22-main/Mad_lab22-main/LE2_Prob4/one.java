class One{
    int y;
    public One(int x){
        this.y = x;
    }
    
    public void get(){
        System.out.println(y);
    }
}
