public class Main
{
	public static void main(String[] args) {
		Two t = new Two();
		t.get();
	}
}
